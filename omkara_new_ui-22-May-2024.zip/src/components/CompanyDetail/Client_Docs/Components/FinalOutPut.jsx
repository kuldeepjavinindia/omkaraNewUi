import { TbArrowsSort } from "react-icons/tb";
import { Button, Typography, Input } from "@material-tailwind/react";
import { CgSearch } from "react-icons/cg";
import { Fragment, useState } from "react";

const FinalOutPut = () => {
  const [isActive, setIsActive] = useState(1);

  const finalOutPutBtn = [
    {
      id: 1,
      label: "All",
      value: "1",
    },
    {
      id: 2,
      label: "Initial Coverage",
      value: "2",
    },
    {
      id: 3,
      label: "Qtr Update",
      value: "3",
    },
    {
      id: 4,
      label: "Others",
      value: "4",
    },
  ];

  return (
    <>
      <div className="col-span-5 mt-5 bg-white py-4 rounded-md">
        <div className="pb-2 border-gray-200 border-b border-0 px-4">
          <div className="flex gap-4 items-center justify-between ">
            <Typography className="text-[15px] text-[#000000] font-semibold">
              Final Output
            </Typography>
            <div>
              <TbArrowsSort className="text-theme" size={18} />
            </div>
          </div>

          <ul className="flex items-center gap-2 my-2">
            {finalOutPutBtn.map((item, index) => (
              <li key={index}>
                <Button
                  size="sm"
                  className={`rounded-md px-3 py-1.5 shadow-none hover:shadow-none capitalize ${
                    item?.value == isActive
                      ? "bg-theme text-white"
                      : "text-[#606F7B]  border border-gray-400 bg-white hover:bg-theme-c2 hover:text-theme hover:border-theme "
                  }`}
                  onClick={() => setIsActive(item?.value)}
                >
                  {item.label}
                </Button>
              </li>
            ))}
          </ul>
          <Input
            type="text"
            placeholder="Search Company"
            className="mt-1 !border !border-gray-200 !h-8 bg-[#E9EDEF] text-gray-900 ring-4 ring-transparent placeholder:text-gray-500 placeholder:opacity-100"
            labelProps={{
              className: "hidden",
            }}
            containerProps={{ className: "min-w-[100px]" }}
            icon={
              <CgSearch
                size={19}
                className=" text-gray-400 top-[-2px] absolute"
              />
            }
          />
        </div>

        <div className="clientDocs_horizontalCardsList px-4">
          <ul>
            <li className="flex items-center gap-4 py-3 border-gray-200 border-b ">
              <img
                src={
                  import.meta.env.VITE_BASE_URL + "/images/icons/pdfIcon.svg"
                }
                alt=""
              />
              <div>
                <Typography className="text-[#162E4C] font-semibold text-[14px]">
                  Tata Coffee Ltd Quater update - Presentation.Pdf
                </Typography>
                <Typography className="text-[10px] text-gray-500">
                  <span className="font-semibold">Abhishek</span> 
                  <span className=" font-medium">•{" "}09-Apr-2022 16:25:00</span> <span className="font-medium">•{" "}Initial Change</span>
                </Typography>
              </div>
            </li>
          </ul>
        </div>
      </div>
      {/* End Component Final Output */}
    </>
  );
};

export default FinalOutPut;
