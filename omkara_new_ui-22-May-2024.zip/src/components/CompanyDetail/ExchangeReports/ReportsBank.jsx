import { TbArrowsSort } from "react-icons/tb";
import { ButtonGroup, Button, Spinner, Typography, Input } from "@material-tailwind/react";
import { CgSearch } from "react-icons/cg";
import { Fragment, useState } from "react";

const ReportsBank = () => {

    const [isActivePrimary, setIsActivePrimary] = useState(2);
const [isActive, setIsActive] = useState(1);


const reportPrimaryBtn = [
    {
        id: 1,
        label: "Company",
        value: "1"
    },
    {
        id: 1,
        label: "Sector",
        value: "2"
    }
]

  const reportSecondaryBtn = [
    {
      id: 1,
      label: "1 Month",
      value: "1",
    },
    {
      id: 2,
      label: "3 Months",
      value: "2",
    },
    {
      id: 3,
      label: "6 Months",
      value: "3",
    },
    {
      id: 4,
      label: "12 Months",
      value: "4",
    },

  ]

  

  return (
   <>
   <div className=" bg-white p-4 rounded-sm">
    <div className="pb-3 border border-gray-400 border-b border-0">
    <div className="flex gap-4 items-center justify-between ">
        <Typography className="text-[15px] text-[#000000] font-semibold mb-2">Report Bank</Typography>
        <TbArrowsSort className="text-theme" />
        </div>
        <ButtonGroup  className=" border-[1px] border-gray-400 rounded-lg mb-3 w-fit">
          {
              reportPrimaryBtn.map((item, i) => {
                return (
                  <Button key={i} 
                    className={`py-2 border-none ${item.value == isActivePrimary ? "bg-[#22242F] text-white" : "bg-white text-[#606F7B]"}  `}
                    onClick={() => { setIsActivePrimary(item.value)}}>
                    {item.label}
                  </Button>
                );
              })
          }
        </ButtonGroup>
          
        <ul className="flex items-center gap-2  mb-2">
          {
            reportSecondaryBtn.map((item, index)=> (
              <li key={index}>
                <Button size="sm" className={` rounded-md px-3 py-1.5 shadow-none hover:shadow-none capitalize  ${item?.value == isActive ? "bg-theme text-white":  "text-[#606F7B]  border border-gray-400 bg-white" }`} 
                onClick={()=> setIsActive(item?.value)}>
                 {item.label}
                </Button>
              </li>
            ))
          }
        </ul>
        

        <Input
            type="text"
            placeholder="Search Company"
            className="mt-1 !border !border-gray-200 !h-8 bg-[#E9EDEF] text-gray-900 ring-4 ring-transparent placeholder:text-gray-500 placeholder:opacity-100"
            labelProps={{
              className: "hidden",
            }}
            containerProps={{ className: "min-w-[100px]" }}
            icon={
              <CgSearch
                size={19}
                className=" text-gray-400 top-[0px] absolute"
              />
            }
          />

    </div>
       
        <div className="clientDocs_horizontalCardsList">
        <ul>
            <li className="flex items-center gap-2 py-3 border-gray-400 border-b border-0 ">
             <Fragment>
             <img src= {import.meta.env.VITE_BASE_URL  + "/images/icons/pdfIcon.svg"} alt="" />
             </Fragment>
             <div >
              <Typography className="text-[#162E4C] font-semibold text-[14px]">
              Tata Coffee Ltd to addas we see limited  
              </Typography>
              <Typography className="text-[13px] text-[#909090]">
                 <span>09-Apr-2022  16:25:00</span>  
              </Typography>
             </div>
            </li>

            <li className="flex items-center gap-2 py-3 border-gray-400 border-b border-0 ">
             <Fragment>
             <img src= {import.meta.env.VITE_BASE_URL  + "/images/icons/pdfIcon.svg"} alt="" />
             </Fragment>
             <div >
              <Typography className="text-[#162E4C] font-semibold text-[14px]">
              Tata Coffee Ltd to addas we see limited  
              </Typography>
              <Typography className="text-[13px] text-[#909090]">
                 <span>09-Apr-2022  16:25:00</span>  
              </Typography>
             </div>
            </li>
        </ul>
        </div>


      </div>
      {/* End Component Final Output */}
   </>
  );
};

export default ReportsBank;
