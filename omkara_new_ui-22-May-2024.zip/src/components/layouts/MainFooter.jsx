

const MainFooter = () => {
  return (
    <footer>
      
    </footer>
  )
}

export default MainFooter
