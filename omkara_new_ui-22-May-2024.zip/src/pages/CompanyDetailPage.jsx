// import React from 'react'
import {
  Tabs,
  TabsHeader,
  TabsBody,
  Tab,
  TabPanel,
  Spinner,
} from "@material-tailwind/react";
import { CD_Main, Client_Docs, ExchangeReports, Financial_Main } from "../components/CompanyDetail";
import { useDispatch, useSelector } from "react-redux";
import { useEffect } from "react";
import { companyNotesAPI } from "../store/slice/SingleCompnaySlice";
import { TrendlyneReq, companyNotesReq } from "../constants/defaultRequest";
import { useParams } from "react-router-dom";
import { useState } from "react";
import { OverviewAPI } from "../store/slice/TrendlyneSlice";
import moment from "moment";




function TabsDefault(props) {

  const {
    TabsData
  } = props
  return (
    <>
    
      <Tabs value="1" className="cd-tabs">
        <TabsHeader

          className="p-0 bg-white tabs-header"
          indicatorProps={{
            className: "bg-theme-c5 shadow-none !text-gray-900  border-theme border-[1px] border-b-0 rounded-none main-tab-indicator top-[1px]",
          }}

        >
          {TabsData.map(({ label, value }) => (
            <Tab key={value} value={value} className="text-sm whitespace-nowrap">
              {label}
            </Tab>
          ))}
        </TabsHeader>
        <TabsBody>
          {TabsData.map(({ value, desc }) => (
            <TabPanel key={value} value={value} className="border-[1px] border-theme bg-theme-c5">
              {desc}
            </TabPanel>
          ))}
        </TabsBody>
      </Tabs>
    </>
  );
}




const CompanyDetailPage = () => {
  
  const rr_dispatch = useDispatch();
  const rrd_params = useParams();

  // const [CompanyData, setCompanyData] = useState({})
  // const [CompanyDataFooter, setCompanyDataFooter] = useState([])
  
  let cmpId = rrd_params?.company_id;
  if(cmpId){
    cmpId = window.atob(cmpId);
  }


  const {
    companyNotes:{
      loading: cmpNotesLoading,
      data: cmpNotesData
    }
  } = useSelector(state=>state.SingleCompany)
  
  let intervalFun = () => {
    setInterval(() => {
      let compSlug = (cmpNotesData.Data?.[0]?.NSEcode || cmpNotesData.Data?.[0]?.BSEcode)
      let params = TrendlyneReq;
      params = {
        ...params,
        compSlug: compSlug
      }
      // console.log('10s >>> hello')
      if( compSlug ){
        rr_dispatch(OverviewAPI(params))
      }
    }, 10000)
  };




  useEffect(() => {
    // console.log('rrd_params >>> ', rrd_params)
    if(cmpNotesLoading){
      let params = companyNotesReq;
      params = {
        ...params,
        CompanyID: cmpId
      }
      rr_dispatch(companyNotesAPI(params))
    }
    if(!cmpNotesLoading){
      // console.log('cmpNotesData >>> ', cmpNotesData)
      // setCompanyData(cmpNotesData?.Data?.[0])
      // setCompanyDataFooter(cmpNotesData?.footer)
    }
  }, [cmpNotesLoading])
  


useEffect(() => {
  intervalFun();
}, [])

  
  useEffect(() => {
    const format = 'HH:mm:ss';

    if(window.location.hostname === 'omkaradata.com'){
      const time_0 = moment().format(format);
      const time = moment(time_0, format);
      const beforeTime = moment('09:14:59', format);
      const afterTime = moment('15:59:59', format);
      if(time.isBetween(beforeTime, afterTime)){
        if(cmpNotesData.Data?.[0] && Object.keys(cmpNotesData.Data?.[0]).length > 0){
          intervalFun();
        }
      }
    }

  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cmpNotesData.Data?.[0]])




  const TypeTabs = [
    {
      value:"1",
      label: cmpNotesData.Data?.[0]?.CompanyName,
      desc:(
        <>
          <CD_Main   />
        </>
      ),
    },
    {
      value:"9",
      label:"Financial",
      desc:(
        <>
          <Financial_Main  />
        </>
      ),
    },
    {
      value:"2",
      label:"Chart",
      desc:(
        <>
          CHART
        </>
      ),
    },
    {
      value:"3",
      label:"Brief",
      desc:(
        <>
          BRIEF
        </>
      ),
    },
    {
      value:"4",
      label:"Client Docs",
      desc:(
        <>
          <Client_Docs />
        </>
      ),
    },
    {
      value:"5",
      label:"Exchange & Reports",
      desc:(
        <>
          <ExchangeReports />
        </>
      ),
    },
    {
      value:"6",
      label:"Forensic",
      desc:(
        <>
          forensic
        </>
      ),
    },
    {
      value:"7",
      label:"Notes",
      desc:(
        <>
          NOTES
        </>
      ),
    },
    {
      value:"8",
      label:"Media Room",
      desc:(
        <>
          MEDIA ROOM
        </>
      ),
    }
  ]

if(cmpNotesLoading){
  return <Spinner className="w-12 h-12" />
}

  return (
    <>
      <div className="sc-container">
        <TabsDefault TabsData={TypeTabs} />
      </div>
    </>
  )
}

export default CompanyDetailPage
