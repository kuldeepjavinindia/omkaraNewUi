import CompanyDetailPage from "./CompanyDetailPage";
import HomePage from "./HomePage";
import BSENewsPage from "./BSENewsPage";
import LoginPage from "./auth/LoginPage";

export {
    HomePage,
    BSENewsPage,
    CompanyDetailPage,
    LoginPage,
}