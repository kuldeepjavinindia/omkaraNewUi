import { AiOutlineCaretDown, AiOutlineCaretUp } from "react-icons/ai"; 
import { BiLinkExternal } from "react-icons/bi"; 
import { AiOutlineLink } from "react-icons/ai"; 
import { Button, Spinner, Typography } from "@material-tailwind/react";
import { useSelector } from "react-redux";
import { Fragment } from "react";
import moment from "moment";

const CD_Main = () => {

  
  const {
    companyNotes:{
      loading: cmpNotesLoading,
      data: cmpNotesData
    }
  } = useSelector(state=>state.SingleCompany)

  const {
    Overview: {
      data: {
        body: OverviewData
      },
      // loading: OverviewLoading,
    }
  } = useSelector(state=>state?.Trendlyne)


  const companyData = cmpNotesData?.Data?.[0] || [];
  const companyFooter = cmpNotesData?.footer || [];
  

  if(cmpNotesLoading){
    return <Spinner className="w-12 h-12" />
  }



  return (
    <div className=" text-black pt-5">
      <div> 
        <div className="flex gap-4">
          <div>
            <Typography className="text-[40px] font-semibold">
              {companyData?.CompanyName}
            </Typography>
            <div className="mt-2 mb-4">
              <ul className="flex gap-3">
                <li>
                  <Button size="sm" className="bg-theme-c2 text-theme flex items-center gap-1 shadow-none rounded ">
                    <AiOutlineLink />
                    <span>{companyData?.WebSiteLink}</span>
                  </Button>
                </li>
                <li>
                  <Button size="sm" className="bg-theme-c2 text-theme flex items-center gap-1 shadow-none rounded">
                    <BiLinkExternal />
                    <span>BSE: {companyData?.BSEcode}</span>
                  </Button>
                </li>
                <li>
                  <Button size="sm" className="bg-theme-c2 text-theme flex items-center gap-1 shadow-none rounded">
                    <BiLinkExternal />
                    <span>NSE: {companyData?.NSEcode}</span>
                  </Button>
                </li>
              </ul>
            </div>
          </div>
          <div>
            <ul className="flex items-center justify-center gap-4">
                <li className="  border-x border-[#C0C5CB] px-2">
 
           <div className="flex gap-2">
           <Typography className="text-[20px] font-bold relative" >
                        {/* ₹ {companyData?.CompanyPrice} */}
                        ₹ {OverviewData && OverviewData?.BSEOHLCData?.ltp}
                    </Typography>
              
                    <div className={`text-[13px] font-bold flex items-baseline ${OverviewData && OverviewData?.BSEOHLCData?.day_changeP > 0 ? 'text-green-300' : 'text-red-300'}`}>
                      {
                        OverviewData && OverviewData?.BSEOHLCData?.day_changeP > 0
                        ?
                        <AiOutlineCaretUp />
                        :
                        <AiOutlineCaretDown />
                      }
                      
                      
                      
                      {OverviewData && OverviewData?.BSEOHLCData?.day_changeP && OverviewData?.BSEOHLCData?.day_changeP.toFixed(2)}%</div>
           </div>
                   
                   
                    <Typography className="text-[#909090] text-[12px]">
                    { OverviewData?.BSEOHLCData?.date && moment(OverviewData?.BSEOHLCData?.date).format('DD-MMM-YYYY hh:mm:ss') }
                    </Typography>
                </li>
                <li className=" font-medium text-[15px]">
                    52wk H/L : <span className="font-semibold">{companyData?.WH52}/{companyData?.WL52}</span>
                </li>
            </ul>
          </div>

       


        </div>
        <div>{/* RIGHT BUTTONS */}</div>
      </div>
      <div className="grid grid-cols-5 gap-4">
        {
          companyFooter.map((f_item, i)=>{
            let a0 = 0;
            
            return (
              <div className="bg-white rounded-sm p-4 font-medium text-[13px]" key={i} >
                <table className="w-full">
                  {
                    Object.keys(f_item).map((child_item,cf)=>{
                      a0++;
                      let row_item = f_item[`row${a0}`];
                      console.log('row_item  >>> ', row_item)

                      return (
                        <Fragment key={cf}>
                          <tr>
                            {
                              row_item && row_item.length > 0 && row_item.map((rItem, rIndex)=>{
                                return (
                                  <td key={rIndex} className="text-start">{rItem?.column}</td>
                                )
                              })
                            }
                          </tr>
                        </Fragment>
                      )
                    })
                  }
                  
                  {/* <tr>
                    <td className="text-start">Total Debt</td>
                    <td className="text-end">958</td>
                  </tr>
                  <tr>
                    <td className="text-start">Cash</td>
                    <td className="text-end">259</td>
                  </tr>
                  <tr>
                    <td className="text-start">Enterprise Value</td>
                    <td className="text-end">7139</td>
                  </tr> */}
                </table>
              </div>
            )
          })
        }
        

        {/* <div className="bg-white rounded-sm p-4 font-medium text-[13px]">
          <table className="w-full">
            <tr>
              <td className="text-start">TTM PE(x)</td>
              <td className="text-end">35.9</td>
            </tr>
            <tr>
              <td className="text-start">5yrs PE(x)</td>
              <td className="text-end">0.0</td>
            </tr>
            <tr>
              <td className="text-start">10yrs PE(x)</td>
              <td className="text-end">0.0</td>
            </tr>
          </table>
        </div>
        <div className="bg-white rounded-sm p-4 font-medium text-[13px]">
          <table className="w-full">
            <tr>
              <td className="text-start">TTM P/BV(x)</td>
              <td className="text-end">3.47</td>
            </tr>
            <tr>
              <td className="text-start">TTM P/BV(x)</td>
              <td className="text-end">0.0</td>
            </tr>
            <tr>
              <td className="text-start">10yrs P/BV(x)</td>
              <td className="text-end">0.0</td>
            </tr>
          </table>
        </div>
        <div className="bg-white rounded-sm p-4 font-medium text-[13px]">
          <table className="w-full">
            <tr>
              <td className="text-start">TTM EV/EBIDTA(x)</td>
              <td className="text-end">3.47</td>
            </tr>
            <tr>
              <td className="text-start">5yrs EV/EBIDTA(x)</td>
              <td className="text-end">0.0</td>
            </tr>
            <tr>
              <td className="text-start">10yrs EV/EBIDTA(x)</td>
              <td className="text-end">0.0</td>
            </tr>
          </table>
        </div>
        <div className="bg-white rounded-sm p-4 font-medium text-[13px]">
          <table className="w-full">
            <tr>
              <td className="text-start">D/E(x)</td>
              <td className="text-end">0.5</td>
            </tr>
            <tr>
              <td className="text-start">ROCE(%)</td>
              <td className="text-end">18</td>
            </tr>
            <tr>
              <td className="text-start">CCC Days</td>
              <td className="text-end">136</td>
            </tr>
          </table>
        </div> */}
      </div>
      <div className="mt-5 bg-white p-4 rounded-sm">
        <Typography className="text-xl font-semibold">About</Typography>
        <Typography className="text-[13px] font-normal text[#22242F]">
          <div dangerouslySetInnerHTML={{ 
            __html: companyData?.companyNotes
           }} />
          {/* Tata Coffee is one of the largest integrated Coffee cultivation and
          processing companies in the world and the largest corporate producer
          of Indian Origin Pepper. With the utmost emphasis on sustainability
          and traceability the company produces some of the finest Indian Origin
          Green Coffee Bean Instant Coffee Pepper and Tea. Tata Coffee is a part
          of the Tata Group.Tata Coffee is one of the largest integrated Coffee
          cultivation and processing companies in the world and the largest
          corporate producer of Indian Origin Pepper. With the utmost emphasis
          on sustainability and traceability the company produces some of the
          finest Indian Origin Green Coffee Bean Instant Coffee Pepper and Tea.
          Tata Coffee is a part of the Tata Group.Tata Coffee is one of the
          largest integrated Coffee cultivation and processing companies in the
          world and the largest corporate producer of Indian Origin Pepper. With
          the utmost emphasis on sustainability and traceability the company
          produces some of the finest Indian Origin Green Coffee Bean Instant
          Coffee Pepper and Tea. Tata Coffee is a part of the Tata Group.Tata
          Coffee is one of the largest integrated Coffee cultivation and
          processing companies in the world and the largest corporate producer
          of Indian Origin Pepper. With the utmost emphasis on sustainability
          and traceability the company produces some of the finest Indian Origin
          Green Coffee Bean Instant Coffee Pepper and Tea. Tata Coffee is a part
          of the Tata Group. */}
        </Typography>
      </div>
    </div>
  );
};

export default CD_Main;
