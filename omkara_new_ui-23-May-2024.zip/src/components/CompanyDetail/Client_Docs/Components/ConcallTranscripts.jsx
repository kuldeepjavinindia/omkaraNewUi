import { Button, Spinner, Typography , Input} from "@material-tailwind/react";
import { FaSortAlphaDown } from "react-icons/fa";
import { CgSearch } from "react-icons/cg";
import { Fragment } from "react";
const ConcallTranscripts = () => {

  return (
   <>

<div className="col-span-4 mt-5 bg-white py-4 rounded-md">
  <div className="pb-2 border-gray-200 border-b border-0 px-4">  
  <div className="flex gap-4 items-center justify-between mb-2">
        <Typography className="text-[15px] text-[#000000] font-semibold">Concall Transcripts</Typography>
        <FaSortAlphaDown className="text-theme" size={18}/>
        </div>
        
        <Input
            type="text"
            placeholder="Search Company"
            className="mt-1 !border !border-gray-200 !h-8 !bg-[#E9EDEF] text-gray-900 ring-4 ring-transparent placeholder:text-gray-500 placeholder:opacity-100"
            labelProps={{
              className: "hidden",
            }}
            containerProps={{ className: "min-w-[100px]" }}
            icon={
              <CgSearch
                size={19}
                className=" text-gray-400 top-0 absolute"
              />
            }
          />
  </div>
  {/* End Top */}

  <div className="clientDocs_horizontalCardsList px-4">
        <ul>
            <li className="flex items-center justify-between gap-2 py-3 border-gray-200 border-b border-0 ">
              <Typography className="text-[#162E4C] font-semibold text-[14px]">
                Feb 2023
              </Typography>
              <div className="flex gap-2 items-stretch">
              <Button size="sm" className={` text-[#1E1E1E] text-[11px] py-1 border-2 border-gray-900  bg-white rounded`} >
              Transcript
                </Button>
                <Button size="sm" className={` text-[#1E1E1E] py-1 px-2 border-gray-900 border-2 bg-white rounded`} >
                  <img src= {import.meta.env.VITE_BASE_URL  + "/images/icons/playEnable.svg"} alt=""  className="w-3.5" />
                </Button>
                <Button size="sm" className={` text-[#1E1E1E] py-1 px-2 border-gray-900 border-2 bg-white rounded`} >
                  <img src= {import.meta.env.VITE_BASE_URL  + "/images/icons/tvEnable.svg"} alt="" className="w-3.5" />
                </Button>
              </div>
            </li>
            
        </ul>
        </div>
     
      </div>
      {/* End Component Concall Transcripts */}
   </>
  );
};

export default ConcallTranscripts;
