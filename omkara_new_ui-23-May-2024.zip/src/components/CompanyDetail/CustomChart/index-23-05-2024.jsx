import Highcharts from "highcharts";
import HighchartsReact from "highcharts-react-official";
import { useEffect, useState } from "react";

const CustomChart = ({
  detail
}) => {


  const [Option, setOption] = useState(null);
  const [IsChart, setIsChart] = useState(false);

  

  useEffect(()=>{
  
      let chartTitle = detail?.title
      const categories = [
        "40FY24",
        "30FY24",
        "2QFY24",
        "IQFY24",
        "4QFY23",
        "3QFY23",
        "2QFY23",
        "IQFY23",
        "4QFY22",
        "3QFY22",
        "2QFY22",
        "IQFY22",
        "4QFY21",
    ];
        
        let options = {
          chart: {
              backgroundColor: 'transparent',
              type: 'bar'
          },
          title: {
              text: chartTitle,
              align: 'center',
              style:{
                fontSize:'13px'
              }
          },
          subtitle: {
              text: `${detail.yoy ? "YOY: "+detail.yoy+" <br />" : ""} ${detail.qoq ? "QOQ: " + detail.qoq : ""}`,
              align: 'center',
              style:{
                fontSize:'12px'
              }
          },
          accessibility: {
              point: {
                  valueDescriptionFormat: '{index}. Age {xDescription}, {value}%.'
              }
          },
          legend:{
            enabled: false
          },
          xAxis: [{

              categories: categories,
              reversed: false,
              labels: {
                  step: 1
              },
              accessibility: {
                  // description: 'Age (male)'
              }
          }],
          yAxis: [{
            labels: {
                  enabled:false,
                  step: 1
              },
            
          }],
      
          plotOptions: {
              // series: {
              //     // stacking: 'normal',
              //     // borderRadius: '50%'
                 
              // }
              bar: {
                borderRadius: '20%',
                dataLabels: {
                    enabled: true
                },
                groupPadding: 0.1
            }
          },
      
          tooltip: {
              // format: '<b>{series.name}, age {point.category}</b><br/>' + 'Population: {(abs point.y):.1f}%'
              format: '<b>{point.category}</b> '
          },
      
          series: [{
              name: '',
              color:'#7B70FF',
              data: [
                1861,
                1821,
                1779,
                1687,
                1751,
                1618,
                1396,
                1250,
                1181,
                1183,
                1112,
                1058,
                1093,
              ]
          }]
      }
      
      setOption(options)
      setIsChart(true);
      
    
    

  }, [])


  return (
    <>

    

    {
      IsChart && (
        <>  
          <HighchartsReact
              containerProps={{ style: { height: "100%" } }}
              highcharts={Highcharts}
              options={Option}
          />
        </>
      )
    }
    </>
  )
}

export default CustomChart
