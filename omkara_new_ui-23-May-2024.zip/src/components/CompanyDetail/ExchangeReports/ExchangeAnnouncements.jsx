import { TbArrowsSort } from "react-icons/tb";
import { Button, Spinner, Typography, Input } from "@material-tailwind/react";
import { CgSearch } from "react-icons/cg";
import { Fragment, useState } from "react";

const ExchangeAnnouncements = () => {

  
  // Start final button handleClick
  const handleClick = (isActive)=> {
      console.log(isActive);
  }
  // End final button handleClick

  return (
   <>
   <div className="  bg-white p-4 rounded-sm">
    <div className="pb-5 border-gray-200 border-b border-0">
    <div className="flex gap-4 items-center justify-between ">
        <Typography className="text-[15px] text-[#000000] font-semibold mb-2">Exchange Announcements</Typography>
        <TbArrowsSort className="text-theme" />
        </div>

        
        <Input
            type="text"
            placeholder="Search Company"
            className="flex mt-1 !border !border-gray-200 !h-8 !bg-[#E9EDEF] text-gray-900 ring-4 ring-transparent placeholder:text-gray-500 placeholder:opacity-100"
            labelProps={{
              className: "hidden",
            }}
            containerProps={{ className: "min-w-[100px]" }}
            icon={
              <CgSearch
                size={17}
                className=" text-gray-400 top-[0px] absolute"
              />
            }
          />

    </div>
       
        <div className="clientDocs_horizontalCardsList">
        <ul>
            <li className="flex items-center gap-2 py-3 border-gray-200 border-b border-0 ">
             <Fragment>
             <img src= {import.meta.env.VITE_BASE_URL  + "/images/icons/pdfIcon.svg"} alt="" />
             </Fragment>
             <div >
              <Typography className="text-[#162E4C] font-semibold text-[14px]">
              Tata Coffee Ltd Quater update - Presentation.Pdf Tata Coffee Ltd Quater update - Presentation.Pdf 
              </Typography>
              <Typography className="text-[13px] text-[#909090]">
                 <span>09-Apr-2022  16:25:00</span>  
              </Typography>
             </div>
            </li>

            <li className="flex items-center gap-2 py-3 border-gray-200 border-b border-0 ">
             <Fragment>
             <img src= {import.meta.env.VITE_BASE_URL  + "/images/icons/pdfIcon.svg"} alt="" />
             </Fragment>
             <div >
              <Typography className="text-[#162E4C] font-semibold text-[14px]">
              Tata Coffee Ltd Quater update - Presentation.Pdf Tata Coffee Ltd Quater update - Presentation.Pdf 
              </Typography>
              <Typography className="text-[13px] text-[#909090]">
                 <span>09-Apr-2022  16:25:00</span>  
              </Typography>
             </div>
            </li>
        </ul>
        </div>


      </div>
      {/* End Component Final Output */}
   </>
  );
};

export default ExchangeAnnouncements;
