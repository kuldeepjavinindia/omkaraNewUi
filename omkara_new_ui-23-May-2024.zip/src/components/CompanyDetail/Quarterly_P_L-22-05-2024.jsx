import { Button, ButtonGroup } from "@material-tailwind/react";
import { useState } from "react";
import Quarterly_P_L_Chart from "./Quarterly_P_L_Chart";
import Quarterly_P_L_Segment from "./Quarterly_P_L_Segment";

const Quarterly_P_L = () => {
  const primaryButton = [
    {
      label: "Consolidate",
      value: "con",
      id: "1",
    },
    {
      label: "Standalone ",
      value: "std",
      id: "2",
    },
  ];

  const secondaryButton = [
    {
      label: "Result",
      component:(
        <>
            Result
        </>
      ),
      value: "con",
      id: "1",
    },
    {
      label: "Segments ",
      component:(
        <>
            <Quarterly_P_L_Segment />
        </>
      ),
      value: "std",
      id: "2",
    },
    {
      label: "Last Quarter ",
      component:(
        <>
            Last Quarter 
        </>
      ),
      value: "std",
      id: "3",
    },
    {
      label: "Chart ",
      component:(
        <>
            <Quarterly_P_L_Chart /> 
        </>
      ),
      value: "std",
      id: "4",
    },
  ];

  const [PrimaryBtn, setPrimaryBtn] = useState(primaryButton[0]);
  const [SecondaryBtn, setSecondaryBtn] = useState(secondaryButton[0]);

  return (
    <>
      <div className="flex justify-between">
        <div>
          <div className="flex gap-2">
            {primaryButton.map((item, i) => (
              <Button
                onClick={() => setPrimaryBtn(item)}
                size="sm"
                variant={`${PrimaryBtn?.id == item?.id ? "" : "outlined"}`}
                className={`${
                  PrimaryBtn?.id == item?.id
                    ? "bg-theme"
                    : "text-theme border-theme"
                }`}
                key={i}
              >
                {item.label}
              </Button>
            ))}
          </div>
          <div className="text-black font-medium mb-2 text-[13px]">
            Quarterly Segment {`"${PrimaryBtn?.label}"`} (showing data from last 12 quarters)
          </div>
        </div>
        <div>
          <ButtonGroup ripple={false} size="sm" className=" border-[1px] border-gray-400 rounded-lg">
            {secondaryButton.map((item, i) => {
              return (
                <Button
                  key={i}
                  className={`border-none ${SecondaryBtn.id == item.id ? "bg-[#22242F] text-white" : "bg-white text-[#606F7B]"}  `}
                  onClick={() => {
                    setSecondaryBtn(item)
                  }}
                >
                  {item.label}
                </Button>
              );
            })}
          </ButtonGroup>
          <div className="flex text-[12px] justify-between text-black">
            <div className=" font-medium">Updated On 25-04-2024 23:55</div>
            <div className=" font-bold">(In Cr.)</div>
          </div>
        </div>
      </div>
        <div>
            {SecondaryBtn.component}
        </div>
    </>
  );
};

export default Quarterly_P_L;
