import { Button } from "@material-tailwind/react"
import CustomChart from "./CustomChart"
import { useState } from "react";

const quarterButton = [
    {
      id:1,
      label:"5 Quarterly",
      len:5
    },
    {
      id:2,
      label:"10 Quarterly",
      len:10
    },
    {
      id:3,
      label:"13 Quarterly",
      len:13
    }
  ]


const Quarterly_P_L_Chart = () => {

    const [QButtonActive, setQButtonActive] = useState(quarterButton[0]);
  return (
    <>
    
        <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
            <div>
            <CustomChart detail={{
                title:"Net Sales (Cr.)",
                yoy:"31.2%",
                qoq:"22.1%",
            }} />
            </div>
            <div>
            <CustomChart  detail={{
                title:"Cons PAT (cr.)",
                yoy:"31.2%",
                qoq:"22.1%",
            }} />
            </div>
            <div>
            <CustomChart  detail={{
                title:"Gross Profit (Cr.)",
                yoy:"31.2%",
                qoq:"22.1%",
            }} />
            </div>
            <div>
            <CustomChart  detail={{
                title:"Gross Margins (%)",
                yoy:"31.2%",
                qoq:"22.1%",
            }} />
            </div>
            <div>
            <CustomChart  detail={{
                title:"EBIDTA (cr.)",
                yoy:"31.2%",
                qoq:"22.1%",
            }} />
            </div>
            <div>
            <CustomChart  detail={{
                title:"EBIDTA Margin (%)",
                yoy:"31.2%",
                qoq:"22.1%",
            }} />
            </div>
        </div>

        <div className="flex gap-2 mt-4 items-center w-full justify-center">
            {
                quarterButton.map((item, i)=>{
                    return (
                        <Button size="sm" onClick={()=>{ setQButtonActive(item) }} variant="outlined" className={`border-theme  ${QButtonActive.id == item.id ? "bg-theme text-white" : "text-theme"}`}  key={i}>{item.label}</Button>
                    )
                })
            }
        </div>
      
    </>
  )
}

export default Quarterly_P_L_Chart
