export const watchListReq = {
  ID: "",
  // UserID: localUser?.UserID,
  WatchListNAme: "",
  status: false,
  input: 4, //1 insert --- 2 update --- 3 delete --- 4 list
};

export const watchListCompanyReq = {
  ID: "",
  // UserID: localUser?.UserID,
  WatchListID: "",
  AccordCode: "",
  CompanyName: "",
  status: false,
  input: 4, //1 insert// 2 update// 3 delete // 4 list
};

export const TrendlyneReq = {
  params: {},
  compSlug: "",
};

export const SignInReq = {
  UserId: "",
  password: "",
};

export const companyMasterReq = {
  Search: "",
};

export const UploadDocumentReq = {
  CompanyID: "",
  UserID: "",
  SectorID: "",
  IndustryID: [],
  DocumentType: "",
  FileName: "",
  FileContent: "",
}; // ADD array

export const companyNotesReq = { CompanyID: "" };
