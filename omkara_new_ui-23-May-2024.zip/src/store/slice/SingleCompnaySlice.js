import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { API_BASE_URL } from "../../constants/helper";

const initialState = {
  companyNotes: {
    loading: true,
    data: [],
    msg: null,
    error: null,
  },
  UploadDocument: {
    loading: true,
    data: [],
    msg: null,
    error: null,
  },
};

// eslint-disable-next-line no-unused-vars
const slice_base_url = API_BASE_URL();

//  USER REQUESTs
let companyNotesReq = `${slice_base_url}/companynote`;
let UploadDocumentReq = `${slice_base_url}/UploadDocument`;


export const companyNotesAPI = createAsyncThunk(
  "companyNotes",
  // eslint-disable-next-line no-unused-vars
  async (all_params = {}) => {
    const response = await axios.post(
      `${companyNotesReq}`,
      all_params
    );
    return response?.data;
  }
);

export const UploadDocumentAPI = createAsyncThunk(
  "UploadDocument",
  // eslint-disable-next-line no-unused-vars
  async (all_params = {}) => {
    const response = await axios.post(
      `${UploadDocumentReq}`,
      all_params
    );
    return response?.data;
  }
);




const TrendlyneSlice = createSlice({
  name: "Trendlyne",
  initialState: initialState,
  reducers: {},
  extraReducers: (builder) => {

    // // START companyNotes DATA
    builder.addCase(companyNotesAPI.pending, (state) => {
      state.companyNotes.loading = true;
      state.companyNotes.error = false;
      state.companyNotes.msgType = null;
    });
    builder.addCase(companyNotesAPI.fulfilled, (state, action) => {
      //   let allData = current(state);

      state.companyNotes.data = action.payload;
      state.companyNotes.loading = false;
      state.companyNotes.msg = "success";
      state.companyNotes.msgType = "success";
    });
    builder.addCase(companyNotesAPI.rejected, (state, action) => {
      state.companyNotes.loading = false;
      state.companyNotes.error = true;
      state.companyNotes.msgType = "error";
      state.companyNotes.msg = action.payload?.msg;
      state.companyNotes.data = action.payload;
    });
    // // END companyNotes DATA
    

    // // START UploadDocument DATA
    builder.addCase(UploadDocumentAPI.pending, (state) => {
      state.UploadDocument.loading = true;
      state.UploadDocument.error = false;
      state.UploadDocument.msgType = null;
    });
    builder.addCase(UploadDocumentAPI.fulfilled, (state, action) => {
      //   let allData = current(state);

      state.UploadDocument.data = action.payload?.Data || [];
      state.UploadDocument.loading = false;
      state.UploadDocument.msg = "success";
      state.UploadDocument.msgType = "success";
    });
    builder.addCase(UploadDocumentAPI.rejected, (state, action) => {
      state.UploadDocument.loading = false;
      state.UploadDocument.error = true;
      state.UploadDocument.msgType = "error";
      state.UploadDocument.msg = action.payload?.msg;
      state.UploadDocument.data = action.payload;
    });
    // // END UploadDocument DATA
    

  },
});

// eslint-disable-next-line no-empty-pattern
export const {} = TrendlyneSlice.actions;

export default TrendlyneSlice.reducer;
