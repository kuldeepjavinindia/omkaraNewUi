import NotesFinalOutput from "./NotesFinalOutput";

const Notes_Main = () => {
  return (
    <div className=" text-black">
      <div className="grid grid-cols-12 gap-2">
      Notes
        {/* <NotesFinalOutput/> */}
      </div>
    </div>
  );
};

export default Notes_Main;
