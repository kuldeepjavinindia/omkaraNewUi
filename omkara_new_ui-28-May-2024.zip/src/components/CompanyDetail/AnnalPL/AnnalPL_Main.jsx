import { useEffect, useState } from 'react'
import { ButtonGroup, Button } from '@material-tailwind/react';
import { useParams } from 'react-router-dom';
import P_L_Statement from './P_L_Statement';
import P_L_Chart from './P_L_Chart';

const AnnalPL_Main = () => {
    const rrd_params = useParams();
    
    let cmpId = rrd_params?.company_id;
    if(cmpId){
      cmpId = window.atob(cmpId);
    }
  

    
    // let primaryBtnArr = [
    //     {
    //       "id":1,
    //       "label":"Consolidated",
    //       "value":"Consolidated",
    //       "short_name":"con",
    //       "show_in":[1,2,3]
    //     },
    //     {
    //       "id":2,
    //       "label":"Standalone",
    //       "value":"Standalone",
    //       "short_name":"std",
    //       "show_in":[1,2,3]
    //     },
    //   ]
    //   let primaryBtnArr = [
    //     {
    //       "id":1,
    //       "label":"P&L Statement",
    //       "component": ""
    //     },
    //     {
    //       "id":2,
    //       "label":"Chart",
    //       "component": ""
    //     }
    //   ]

    const primaryButton = [
        {
          label: "Consolidate",
          isConStd:true,
          value: "con",
          id: "1",
        },
        {
          label: "Standalone ",
          value: "std",
          id: "2",
        },
      ];
    
      const secondaryButton = [
        {
          label: "P&L Statement",
          component:(
            <>
                <P_L_Statement />
            </>
          ),
          value: "con",
          id: "1",
        },
        {
          label: "Chart ",
          isConStd:true,
          component:(
            <>
                <P_L_Chart />
            </>
          ),
          value: "std",
          id: "2",
        },
      ];

      
  const [PrimaryBtn, setPrimaryBtn] = useState(primaryButton[0]);
  const [SecondaryBtn, setSecondaryBtn] = useState(secondaryButton[0]);

      
      



  return (
    <>
      

      <div className="flex justify-between mb-2">
        <div>
          <div className="flex gap-2 mb-4">
            {primaryButton.map((item, i) => (
              <Button
                onClick={() => setPrimaryBtn(item)}
                size="sm"
                variant={`${PrimaryBtn?.id == item?.id ? "" : "outlined"}`}
                className={`${
                  PrimaryBtn?.id == item?.id
                    ? "bg-theme"
                    : "text-theme border-theme"
                }`}
                key={i}
              >
                {item.label}
              </Button>
            ))}
          </div>
          {/* <div className="text-black font-medium mb-2 text-[13px]">
            Quarterly Segment {`"${PrimaryBtn?.label}"`} (showing data from last 12 quarters)
          </div> */}
        </div>
        <div>
          <ButtonGroup ripple={false} size="sm" className=" border-[1px] rounded-lg mb-4 shadow-none">
            {secondaryButton.map((item, i) => {
              return (
                <Button
                  key={i} 
                  className={`border-none  shadow-none hover:shadow-none ${SecondaryBtn.id == item.id ? "bg-[#22242F] text-white" : "bg-white text-[#606F7B]"}  `}
                  onClick={() => {
                    setSecondaryBtn(item)
                  }}
                >
                  {item.label}
                </Button>
              );
            })}
          </ButtonGroup>

          {/* <div className="flex text-[12px] justify-between text-black">
            <div className=" font-medium">Updated On 25-04-2024 23:55</div>
            <div className=" font-bold">(In Cr.)</div>
          </div> */}
        </div>
      </div>


      
      <div>
            {SecondaryBtn.component}
        </div>



    </>
  )
}

export default AnnalPL_Main
