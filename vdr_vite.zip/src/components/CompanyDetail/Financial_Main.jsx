import {
    Tabs,
    TabsHeader,
    TabsBody,
    Tab,
    TabPanel,
  } from "@material-tailwind/react";
import Quarterly_P_L from "./Quarterly_P_L";
import { useState } from "react";
   
// QUARTERLY P&L
// ANNAL P&L
// BALLANCE SHEET
// CASH FLOWS
// RATIOS
// PEERS
// SHAREHOLDING %

  export function TabsDefault({
    ActiveTab, setActiveTab
  }) {


    const data = [
      {
        label: "QUARTERLY P&L",
        value: "1",
        desc: (
            <>
                <Quarterly_P_L />
            </>
        ),
      },
      {
        label: "ANNAL P&L",
        value: "2",
        desc: `ANNAL P&L`,
      },
      {
        label: "BALLANCE SHEET",
        value: "3",
        desc: `BALLANCE SHEET`,
      },
      {
        label: "CASH FLOWS",
        value: "4",
        desc: `CASH FLOWS`,
      },
      {
        label: "RATIOS",
        value: "5",
        desc: `RATIOS`,
      },
      {
        label: "PEERS",
        value: "6",
        desc: `PEERS`,
      },
      {
        label: "SHAREHOLDING %",
        value: "7",
        desc: `SHAREHOLDING %`,
      },
    ];
   
    return (
      <Tabs value="1">
        <TabsHeader className="" 
            indicatorProps={{
                className: "bg-theme-c2 text-theme shadow-none border-theme border-[1px]",
            }}
          >
          {data.map(({ label, value }) => (
            <Tab
                className={`w-fit text-[13px] font-medium ${ActiveTab === value ? "text-theme font-semibold" : ""}`} key={value} value={value} onClick={() => setActiveTab(value)}
                
            >
              {label}
            </Tab>
          ))}
        </TabsHeader>
        <TabsBody>
          {data.map(({ value, desc }) => (
            <TabPanel key={value} value={value}>
              {desc}
            </TabPanel>
          ))}
        </TabsBody>
      </Tabs>
    );
  }


const Financial_Main = () => {

  
  const [ActiveTab, setActiveTab] = useState(1)

  return (
    <>
      <TabsDefault ActiveTab={ActiveTab} setActiveTab={setActiveTab} />
    </>
  )
}

export default Financial_Main
