import { Button, Typography } from "@material-tailwind/react";
import {} from "react";

const Quarterly_P_L_Segment = () => {
  return (
    <>
      <div className="pl_segment-container">
        <table className="w-full min-w-max table-auto text-left">
          <thead>
            <tr>
              <th className="border-b border-blue-gray-100 bg-[#22242F] text-white p-2 text-[13px] font-medium">
                Description
              </th>
              <th className="border-b border-blue-gray-100 bg-[#22242F] text-white p-2 text-[13px] font-medium">
                4QFY23
              </th>
              <th className="border-b border-blue-gray-100 bg-[#22242F] text-white p-2 text-[13px] font-medium">
                4QFY22
              </th>
              <th className="border-b border-blue-gray-100 bg-[#22242F] text-white p-2 text-[13px] font-medium">
                4QFY22
              </th>
              <th className="border-b border-blue-gray-100 bg-[#22242F] text-white p-2 text-[13px] font-medium">
                3QFY23
              </th>
              <th className="border-b border-blue-gray-100 bg-[#22242F] text-white p-2 text-[13px] font-medium">
                QoQ(%)
              </th>
              <th className="border-b border-blue-gray-100 bg-[#22242F] text-white p-2 text-[13px] font-medium">
                2HFY23
              </th>
              <th className="border-b border-blue-gray-100 bg-[#22242F] text-white p-2 text-[13px] font-medium">
                2HFY22
              </th>
              <th className="border-b border-blue-gray-100 bg-[#22242F] text-white p-2 text-[13px] font-medium">
                4QFY22
              </th>
            </tr>
          </thead>
          <tbody className="text-black">
            <tr className="odd:bg-[#E8F0F4] even:bg-[#fff]">
                <td className="px-2 py-1 text-[13px] font-medium" colSpan={9}>
                    <div className="flex  justify-between w-full">
                        <Typography className=" font-bold text-[14px]">Sales</Typography>
                        <div className="flex gap-2">
                            <Button variant="outlined" size="sm" className="py-0 text-[11px] bg-white text-theme border-theme rounded">AMOUNT</Button>
                            <Button variant="outlined" size="sm" className="py-0 text-[11px] bg-white text-gray-600 border-gray-400 rounded">ANNAL P&L</Button>
                        </div>
                    </div>
                </td>
            </tr>
            <tr className="odd:bg-[#E8F0F4] even:bg-[#fff]">
                <td className="px-2 py-1 text-[13px] font-medium">Consolidate </td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
            </tr>
            <tr className="odd:bg-[#E8F0F4] even:bg-[#fff]">
                <td className="px-2 py-1 text-[13px] font-medium">Quarterly Period </td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
            </tr>
            <tr className="odd:bg-[#E8F0F4] even:bg-[#fff]">
                <td className="px-2 py-1 text-[13px] font-medium">Net Sales </td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
            </tr>
            <tr className="odd:bg-[#E8F0F4] even:bg-[#fff]">
                <td className="px-2 py-1 text-[13px] font-medium">Cost of Goods Sold </td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
            </tr>
            <tr className="odd:bg-[#E8F0F4] even:bg-[#fff]">
                <td className="px-2 py-1 text-[13px] font-medium">% of Sales </td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
            </tr>
            <tr className="odd:bg-[#E8F0F4] even:bg-[#fff]">
                <td className="px-2 py-1 text-[13px] font-medium" colSpan={9}>
                    <div className="flex  justify-between w-full">
                        <Typography className=" font-bold text-[14px]">Profit before Tax & Int</Typography>
                        <div className="flex gap-2">
                            <Button variant="outlined" size="sm" className="py-0 text-[11px] bg-white text-theme border-theme rounded">AMOUNT</Button>
                            <Button variant="outlined" size="sm" className="py-0 text-[11px] bg-white text-gray-600 border-gray-400 rounded">MARGIN%</Button>
                            <Button variant="outlined" size="sm" className="py-0 text-[11px] bg-white text-gray-600 border-gray-400 rounded">GROWTH%</Button>
                        </div>
                    </div>
                </td>
            </tr>
            <tr className="odd:bg-[#E8F0F4] even:bg-[#fff]">
                <td className="px-2 py-1 text-[13px] font-medium">Consolidate </td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
            </tr>
            <tr className="odd:bg-[#E8F0F4] even:bg-[#fff]">
                <td className="px-2 py-1 text-[13px] font-medium">Quarterly Period </td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
            </tr>
            <tr className="odd:bg-[#E8F0F4] even:bg-[#fff]">
                <td className="px-2 py-1 text-[13px] font-medium">Net Sales </td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
            </tr>
            <tr className="odd:bg-[#E8F0F4] even:bg-[#fff]">
                <td className="px-2 py-1 text-[13px] font-medium">Cost of Goods Sold </td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
            </tr>
            <tr className="odd:bg-[#E8F0F4] even:bg-[#fff]">
                <td className="px-2 py-1 text-[13px] font-medium">% of Sales </td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
            </tr>
            <tr className="odd:bg-[#E8F0F4] even:bg-[#fff]">
                <td className="px-2 py-1 text-[13px] font-medium" colSpan={9}>
                    <div className="flex  justify-between w-full">
                        <Typography className=" font-bold text-[14px]">Capital Employed</Typography>
                        <div className="flex gap-2">
                            {/* <Button variant="outlined" size="sm" className="py-0 text-[11px] bg-white text-theme border-theme">AMOUNT</Button>
                            <Button variant="outlined" size="sm" className="py-0 text-[11px] bg-white text-gray-600 border-gray-400">MARGIN%</Button>
                            <Button variant="outlined" size="sm" className="py-0 text-[11px] bg-white text-gray-600 border-gray-400">GROWTH%</Button> */}
                        </div>
                    </div>
                </td>
            </tr>
            <tr className="odd:bg-[#E8F0F4] even:bg-[#fff]">
                <td className="px-2 py-1 text-[13px] font-medium">Consolidate </td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
            </tr>
            <tr className="odd:bg-[#E8F0F4] even:bg-[#fff]">
                <td className="px-2 py-1 text-[13px] font-medium">Quarterly Period </td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
            </tr>
            <tr className="odd:bg-[#E8F0F4] even:bg-[#fff]">
                <td className="px-2 py-1 text-[13px] font-medium">Net Sales </td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
            </tr>
            <tr className="odd:bg-[#E8F0F4] even:bg-[#fff]">
                <td className="px-2 py-1 text-[13px] font-medium">Cost of Goods Sold </td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
            </tr>
            <tr className="odd:bg-[#E8F0F4] even:bg-[#fff]">
                <td className="px-2 py-1 text-[13px] font-medium">% of Sales </td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
                <td className="px-2 py-1 text-[13px] font-medium">10204</td>
            </tr>
          </tbody>
        </table>
      </div>
    </>
  );
};

export default Quarterly_P_L_Segment;
