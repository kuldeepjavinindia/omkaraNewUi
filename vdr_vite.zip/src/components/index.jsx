import MainLayout from "./layouts/MainLayout";

export {
    MainLayout
}