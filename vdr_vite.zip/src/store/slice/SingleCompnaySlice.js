import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { API_BASE_URL } from "../../constants/helper";

const initialState = {
  companyNotes: {
    loading: true,
    data: [],
    msg: null,
    error: null,
  },
  UploadDocument: {
    loading: true,
    data: [],
    msg: null,
    error: null,
  },
  RepositoryList: {
    loading: true,
    data: [],
    msg: null,
    error: null,
  },
  UploadDocumentAnalysNote: {
    loading: true,
      data: [],
      msg: null,
      error: null,
    }

};

// eslint-disable-next-line no-unused-vars
const slice_base_url = API_BASE_URL();

//  USER REQUESTs
let companyNotesReq = `${slice_base_url}/companynote`;
let UploadDocumentReq = `${slice_base_url}/UploadDocument`;
let RepositoryListReq = `${slice_base_url}/RepositoryListTesting`;
let UploadDocumentAnalysNotesReq = `${slice_base_url}/UploadDocumentAnalystNotes`;

let QuarterlyResultReq = `${slice_base_url}/QuarterlyResultsConsolidated_ACEAPI`;
let Data20YearsReq = `${slice_base_url}/Data20YearsSingleCompany_ACEAPI`;
let QtrSegmentReq = `${slice_base_url}/QtrSegment_ACEAPI`;
let QuaterlyResultSnapShotReq = `${slice_base_url}/QuaterlyResultSnapShot_ACEAPI`;
let AnnualP_LReq = `${slice_base_url}/QuaterlyResult_ProfitAndLoss_ACEAPI`;






export const companyNotesAPI = createAsyncThunk(
  "companyNotes",
  // eslint-disable-next-line no-unused-vars
  async (all_params = {}) => {
    const response = await axios.post(
      `${companyNotesReq}`,
      all_params
    );
    return response?.data;
  }
);

export const UploadDocumentAPI = createAsyncThunk(
  "UploadDocument",
  // eslint-disable-next-line no-unused-vars
  async (all_params = {}) => {
    const response = await axios.post(
      `${UploadDocumentReq}`,
      all_params
    );
    return response?.data;
  }
);

export const RepositoryListAPI = createAsyncThunk(
  "RepositoryList",
  // eslint-disable-next-line no-unused-vars
  async (all_params = {}) => {
    const response = await axios.post(
      `${RepositoryListReq}`,
      all_params
    );
    return response?.data;
  }
);

// UploadDocumentAnalysNoteApi Thunk
export const UploadDocumentAnalysNoteApi = createAsyncThunk(
  "UploadDocumentAnalysNote",
  async (all_params = {})=> {
    const response = await axios.post( `${UploadDocumentAnalysNotesReq}`, all_params);
    return response?.data;
  }
);



export const QuarterlyResultReqApi = createAsyncThunk(
  "QuarterlyResultReq",
  async (all_params = {})=> {
    const response = await axios.post( `${QuarterlyResultReq}`, all_params);
    return response?.data;
  }
);


export const Data20YearsSReqApi = createAsyncThunk(
  "Data20YearsSReq",
  async (all_params = {})=> {
    const response = await axios.post( `${Data20YearsSReq}`, all_params);
    return response?.data;
  }
);


const SingleCompanySlice = createSlice({
  name: "SingleCompany",
  initialState: initialState,
  reducers: {},
  extraReducers: (builder) => {

    // // START companyNotes DATA
    builder.addCase(companyNotesAPI.pending, (state) => {
      state.companyNotes.loading = true;
      state.companyNotes.error = false;
      state.companyNotes.msgType = null;
    });
    builder.addCase(companyNotesAPI.fulfilled, (state, action) => {
      //   let allData = current(state);

      state.companyNotes.data = action.payload;
      state.companyNotes.loading = false;
      state.companyNotes.msg = "success";
      state.companyNotes.msgType = "success";
    });
    builder.addCase(companyNotesAPI.rejected, (state, action) => {
      state.companyNotes.loading = false;
      state.companyNotes.error = true;
      state.companyNotes.msgType = "error";
      state.companyNotes.msg = action.payload?.msg;
      state.companyNotes.data = action.payload;
    });
    // // END companyNotes DATA
    

    // // START UploadDocument DATA
    builder.addCase(UploadDocumentAPI.pending, (state) => {
      state.UploadDocument.loading = true;
      state.UploadDocument.error = false;
      state.UploadDocument.msgType = null;
    });
    builder.addCase(UploadDocumentAPI.fulfilled, (state, action) => {
      //   let allData = current(state);

      state.UploadDocument.data = action.payload?.Data || [];
      state.UploadDocument.loading = false;
      state.UploadDocument.msg = "success";
      state.UploadDocument.msgType = "success";
    });
    builder.addCase(UploadDocumentAPI.rejected, (state, action) => {
      state.UploadDocument.loading = false;
      state.UploadDocument.error = true;
      state.UploadDocument.msgType = "error";
      state.UploadDocument.msg = action.payload?.msg;
      state.UploadDocument.data = action.payload;
    });
    // // END UploadDocument DATA
    

    // // START RepositoryList DATA
    builder.addCase(RepositoryListAPI.pending, (state) => {
      state.RepositoryList.loading = true;
      state.RepositoryList.error = false;
      state.RepositoryList.msgType = null;
    });
    builder.addCase(RepositoryListAPI.fulfilled, (state, action) => {
      //   let allData = current(state);

      state.RepositoryList.data = action.payload?.Data || [];
      state.RepositoryList.loading = false;
      state.RepositoryList.msg = "success";
      state.RepositoryList.msgType = "success";
    });
    builder.addCase(RepositoryListAPI.rejected, (state, action) => {
      state.RepositoryList.loading = false;
      state.RepositoryList.error = true;
      state.RepositoryList.msgType = "error";
      state.RepositoryList.msg = action.payload?.msg;
      state.RepositoryList.data = action.payload;
    });
    // // END RepositoryList DATA


    // Start UploadDocumentAnalysNoteData
    builder.addCase(UploadDocumentAnalysNoteApi.pending, (state)=> {
      state.UploadDocumentAnalysNote.loading = true,
      state.UploadDocumentAnalysNote.error = false,
      state.UploadDocumentAnalysNote.msg = false
  });
  builder.addCase(UploadDocumentAnalysNoteApi.fulfilled, (state, action)=> {
    state.UploadDocumentAnalysNote.loading = false,
    state.UploadDocumentAnalysNote.data = action.payload;
    state.UploadDocumentAnalysNote.msg = "success"
    // state.UploadDocumentAnalysNote.error = state.UploadDocumentAnalysNote.error
});
builder.addCase(UploadDocumentAnalysNoteApi.rejected, (state, action)=> {
  state.UploadDocumentAnalysNote.loading = false,
  state.UploadDocumentAnalysNote.data = action.payload;
  state.UploadDocumentAnalysNote.msg = action.payload?.msg
  state.UploadDocumentAnalysNote.error = true
});
// End UploadDocumentAnalysNoteData
    

  },
});

// eslint-disable-next-line no-empty-pattern
export const {} = SingleCompanySlice.actions;

export default SingleCompanySlice.reducer;
